# Local validation — 2026-11-06

This report covers the local Stage A milestone. No personal integrations or hosted resources were used.

| Check                  | Observed result                                                                             |
| ---------------------- | ------------------------------------------------------------------------------------------- |
| `npm run typecheck`    | Passed                                                                                      |
| `npm run lint`         | Passed with no warnings in the final run                                                    |
| `npm run format:check` | Passed                                                                                      |
| `npm test`             | 36 tests passed across five files                                                           |
| `npm run build`        | Optimized Next.js production build passed                                                   |
| `npm run test:e2e`     | Four tests passed against production Next.js + test-only PostgreSQL-backed Supabase adapter |
| `npm audit --omit=dev` | Zero known advisories reported at check time                                                |

## What the tests establish

- PostgreSQL migration execution, per-user RLS, denial to unapproved/anonymous identities, cross-user and nested academic reference rejection.
- RLS enabled on every private application table; server-only credentials and provider state inaccessible for client writes.
- Optimistic version changes, stale-write rejection, soft deletion/recovery, append-only audit protection, circular dependency prevention, unique occurrences and idempotent test examples.
- An independent local engine snapshot restores into another PGlite instance with matching task/audit counts and ownership enforcement.
- Unknown grades remain NULL. Fixed-precision money is preserved and transfers are excluded from expense totals.
- Scheduler determinism, local work windows, session sizes, busy-event exclusion, breaks, existing daily workload cap, frozen-block preservation, dependencies, excluded areas, missing estimates, actual-time accounting, explicit infeasibility, historical DST and current Vancouver rules.
- Offline Calendar normalization, all-day dates, recurring source metadata, paging/deduplication, 410 sync-token recovery, protected-calendar write boundaries; explicit Sheets mapping/schema detection; tenant-bound authenticated token encryption.
- Browser sign-in through the synthetic test adapter, task capture and persistence after reload, completion/delete/restore, project/goal creation, recurring generation and individual completion, scheduling previews, review drafts/reopening/completion, export, sign-out and protected redirects.
- API origin rejection, stale-edit rejection, and preservation of a completed task's original completion timestamp during later edits.
- iPhone-sized navigation, no horizontal overflow on tested pages, modal Escape dismissal, automated WCAG A/AA scans on core screens and a task form, including dark and light themes.

## What is not established

- Real Supabase GoTrue/PostgREST compatibility/configuration, password recovery, MFA, hosted rate limits, or revoked-provider credential behavior.
- A complete Supabase/pg_dump/Auth/secret recovery rehearsal. PGlite snapshot recovery is narrower.
- Real Google OAuth, actual calendars/spreadsheet access, integration persistence, live provider reconciliation or any Calendar write.
- Durable workers, automatic retries, actual job execution, closed-app notifications or push delivery.
- Full WCAG 2.2 AA conformance, manual screen-reader coverage, actual Safari/iPhone/iPad behavior, or measured p75 performance targets.
- Vercel deployment, hosted reliability, billing/quota configuration, or approval for stages B/C/D.

No background job, Google write, personal import or paid service was activated. Finance and Wellbeing remain empty in the application; database financial tests use only isolated synthetic records.
